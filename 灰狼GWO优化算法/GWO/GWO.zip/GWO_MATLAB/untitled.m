for i = 1:5
    func_name = strcat('F', num2str(i));
    disp(func_name);
end
